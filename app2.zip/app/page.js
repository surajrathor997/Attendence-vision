
"use client"
import Image from "next/image";
import Web from "./index.js";
import Header from "./Header.js";

export default function Home() {
  return (
    <>
    
    <Web />   
    </>  
                              
  );
}
